/* EdgeIQ — Popup Script */
(function () {
  'use strict';

  const DEFAULT_BACKEND = 'https://edgeiq-production-6e47.up.railway.app';

  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const statusUrl = document.getElementById('statusUrl');
  const backendUrlInput = document.getElementById('backendUrlInput');
  const saveBtn = document.getElementById('saveBtn');
  const saveFeedback = document.getElementById('saveFeedback');

  // ─── Check current tab URL ───────────────────────────────────────────────────
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    const url = tab && tab.url ? tab.url : '';

    const isOnTab = /tab\.com\.au\/(racing|sports)/i.test(url);

    if (isOnTab) {
      statusDot.classList.add('active');
      statusText.classList.add('active');
      statusText.textContent = 'Active on TAB.com.au';
      // Show the path portion of the URL
      try {
        const parsed = new URL(url);
        statusUrl.textContent = parsed.hostname + parsed.pathname;
      } catch (_) {
        statusUrl.textContent = url.slice(0, 60);
      }
    } else if (url && url.includes('tab.com.au')) {
      statusDot.classList.add('inactive');
      statusText.classList.add('inactive');
      statusText.textContent = 'On TAB — navigate to Racing or Sports';
      try {
        const parsed = new URL(url);
        statusUrl.textContent = parsed.hostname + parsed.pathname;
      } catch (_) {
        statusUrl.textContent = url.slice(0, 60);
      }
    } else {
      statusDot.classList.add('inactive');
      statusText.classList.add('inactive');
      statusText.textContent = 'Not on TAB page';
      statusUrl.textContent = url ? url.slice(0, 60) : '';
    }
  });

  // ─── Load saved backend URL ──────────────────────────────────────────────────
  chrome.storage.sync.get('backendUrl', (result) => {
    backendUrlInput.value = result.backendUrl || DEFAULT_BACKEND;
  });

  // ─── Save backend URL ────────────────────────────────────────────────────────
  saveBtn.addEventListener('click', () => {
    const url = backendUrlInput.value.trim();

    if (!url) {
      showFeedback('Please enter a URL.', true);
      return;
    }

    // Basic URL validation
    try {
      new URL(url);
    } catch (_) {
      showFeedback('Invalid URL — please include https://', true);
      return;
    }

    chrome.storage.sync.set({ backendUrl: url }, () => {
      if (chrome.runtime.lastError) {
        showFeedback('Save failed: ' + chrome.runtime.lastError.message, true);
      } else {
        showFeedback('Saved!', false);
      }
    });
  });

  // Allow pressing Enter to save
  backendUrlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveBtn.click();
  });

  function showFeedback(msg, isError) {
    saveFeedback.textContent = msg;
    saveFeedback.style.color = isError ? '#e85c5c' : '#39d97c';
    saveFeedback.style.opacity = '1';

    setTimeout(() => {
      saveFeedback.style.opacity = '0';
      setTimeout(() => {
        saveFeedback.textContent = '';
        saveFeedback.style.opacity = '1';
      }, 400);
    }, 2500);
  }
})();
